﻿using System;
using System.Windows.Forms;

namespace Blackjack
{
    partial class BlackjackForm
    {
        #region Windows Forms Designer generated code
        private void InitializeComponent()
        {
            this.ClrBetBtn = new System.Windows.Forms.Button();
            this.playerBetlbl = new System.Windows.Forms.Label();
            this.btn100 = new System.Windows.Forms.Button();
            this.playerBettb = new System.Windows.Forms.TextBox();
            this.playerBanktb = new System.Windows.Forms.TextBox();
            this.btn25 = new System.Windows.Forms.Button();
            this.btn50 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.playerBanklbl = new System.Windows.Forms.Label();
            this.deckCard3pb = new System.Windows.Forms.PictureBox();
            this.dealerCard1pb = new System.Windows.Forms.PictureBox();
            this.deckCard1pb = new System.Windows.Forms.PictureBox();
            this.deckCard2pb = new System.Windows.Forms.PictureBox();
            this.dealerCard2pb = new System.Windows.Forms.PictureBox();
            this.dealerCard3pb = new System.Windows.Forms.PictureBox();
            this.dealerCard4pb = new System.Windows.Forms.PictureBox();
            this.dealerCard5pb = new System.Windows.Forms.PictureBox();
            this.dealerCard6pb = new System.Windows.Forms.PictureBox();
            this.playerCard1 = new System.Windows.Forms.PictureBox();
            this.playerCard2 = new System.Windows.Forms.PictureBox();
            this.playerCard3 = new System.Windows.Forms.PictureBox();
            this.Winstb = new System.Windows.Forms.TextBox();
            this.Lossestb = new System.Windows.Forms.TextBox();
            this.Tiestb = new System.Windows.Forms.TextBox();
            this.Winslbl = new System.Windows.Forms.Label();
            this.Tieslbl = new System.Windows.Forms.Label();
            this.Losseslbl = new System.Windows.Forms.Label();
            this.NewGamebtn = new System.Windows.Forms.Button();
            this.Dealbtn = new System.Windows.Forms.Button();
            this.Standbtn = new System.Windows.Forms.Button();
            this.Hitbtn = new System.Windows.Forms.Button();
            this.GameOvertb = new System.Windows.Forms.TextBox();
            this.DoubleDownbtn = new System.Windows.Forms.Button();
            this.Recordpnl = new System.Windows.Forms.Panel();
            this.Betpnl = new System.Windows.Forms.Panel();
            this.PlayerHandTotaltb = new System.Windows.Forms.TextBox();
            this.playerHandTotallbl = new System.Windows.Forms.Label();
            this.DealerHandTotallbl = new System.Windows.Forms.Label();
            this.DealerHandTotaltb = new System.Windows.Forms.TextBox();
            this.ExitGamebtn = new System.Windows.Forms.Button();
            this.playerCard6 = new System.Windows.Forms.PictureBox();
            this.playerCard5 = new System.Windows.Forms.PictureBox();
            this.playerCard4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.deckCard3pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard1pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deckCard1pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deckCard2pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard2pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard3pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard4pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard5pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard6pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard4)).BeginInit();
            this.SuspendLayout();
            // 
            // ClrBetBtn
            // 
            this.ClrBetBtn.Location = new System.Drawing.Point(483, 234);
            this.ClrBetBtn.Name = "ClrBetBtn";
            this.ClrBetBtn.Size = new System.Drawing.Size(58, 23);
            this.ClrBetBtn.TabIndex = 0;
            this.ClrBetBtn.Text = "Clear Bet";
            this.ClrBetBtn.UseVisualStyleBackColor = true;
            this.ClrBetBtn.Click += new System.EventHandler(this.ClrBetBtn_Click);
            // 
            // playerBetlbl
            // 
            this.playerBetlbl.AutoSize = true;
            this.playerBetlbl.BackColor = System.Drawing.Color.Transparent;
            this.playerBetlbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.playerBetlbl.Location = new System.Drawing.Point(374, 215);
            this.playerBetlbl.Name = "playerBetlbl";
            this.playerBetlbl.Size = new System.Drawing.Size(48, 13);
            this.playerBetlbl.TabIndex = 1;
            this.playerBetlbl.Text = "Your Bet";
            // 
            // btn100
            // 
            this.btn100.Location = new System.Drawing.Point(388, 263);
            this.btn100.Name = "btn100";
            this.btn100.Size = new System.Drawing.Size(34, 23);
            this.btn100.TabIndex = 3;
            this.btn100.Text = "100";
            this.btn100.UseVisualStyleBackColor = true;
            this.btn100.Click += new System.EventHandler(this.btn100_Click);
            // 
            // playerBettb
            // 
            this.playerBettb.Location = new System.Drawing.Point(377, 237);
            this.playerBettb.Name = "playerBettb";
            this.playerBettb.Size = new System.Drawing.Size(100, 20);
            this.playerBettb.TabIndex = 11;
            // 
            // playerBanktb
            // 
            this.playerBanktb.Location = new System.Drawing.Point(377, 349);
            this.playerBanktb.Name = "playerBanktb";
            this.playerBanktb.Size = new System.Drawing.Size(100, 20);
            this.playerBanktb.TabIndex = 12;
            // 
            // btn25
            // 
            this.btn25.Location = new System.Drawing.Point(388, 292);
            this.btn25.Name = "btn25";
            this.btn25.Size = new System.Drawing.Size(34, 23);
            this.btn25.TabIndex = 13;
            this.btn25.Text = "25";
            this.btn25.UseVisualStyleBackColor = true;
            this.btn25.Click += new System.EventHandler(this.btn25_Click);
            // 
            // btn50
            // 
            this.btn50.Location = new System.Drawing.Point(428, 263);
            this.btn50.Name = "btn50";
            this.btn50.Size = new System.Drawing.Size(34, 23);
            this.btn50.TabIndex = 14;
            this.btn50.Text = "50";
            this.btn50.UseVisualStyleBackColor = true;
            this.btn50.Click += new System.EventHandler(this.btn50_Click);
            // 
            // btn10
            // 
            this.btn10.Location = new System.Drawing.Point(428, 292);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(34, 23);
            this.btn10.TabIndex = 15;
            this.btn10.Text = "10";
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // playerBanklbl
            // 
            this.playerBanklbl.AutoSize = true;
            this.playerBanklbl.BackColor = System.Drawing.Color.Transparent;
            this.playerBanklbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.playerBanklbl.Location = new System.Drawing.Point(374, 333);
            this.playerBanklbl.Name = "playerBanklbl";
            this.playerBanklbl.Size = new System.Drawing.Size(57, 13);
            this.playerBanklbl.TabIndex = 16;
            this.playerBanklbl.Text = "Your Bank";
            // 
            // deckCard3pb
            // 
            this.deckCard3pb.BackColor = System.Drawing.Color.Transparent;
            this.deckCard3pb.Location = new System.Drawing.Point(866, 15);
            this.deckCard3pb.Name = "deckCard3pb";
            this.deckCard3pb.Size = new System.Drawing.Size(130, 180);
            this.deckCard3pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.deckCard3pb.TabIndex = 19;
            this.deckCard3pb.TabStop = false;
            // 
            // dealerCard1pb
            // 
            this.dealerCard1pb.BackColor = System.Drawing.Color.Transparent;
            this.dealerCard1pb.Location = new System.Drawing.Point(10, 29);
            this.dealerCard1pb.Name = "dealerCard1pb";
            this.dealerCard1pb.Size = new System.Drawing.Size(130, 180);
            this.dealerCard1pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dealerCard1pb.TabIndex = 20;
            this.dealerCard1pb.TabStop = false;
            // 
            // deckCard1pb
            // 
            this.deckCard1pb.BackColor = System.Drawing.Color.Transparent;
            this.deckCard1pb.Location = new System.Drawing.Point(853, 32);
            this.deckCard1pb.Name = "deckCard1pb";
            this.deckCard1pb.Size = new System.Drawing.Size(130, 180);
            this.deckCard1pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.deckCard1pb.TabIndex = 21;
            this.deckCard1pb.TabStop = false;
            // 
            // deckCard2pb
            // 
            this.deckCard2pb.BackColor = System.Drawing.Color.Transparent;
            this.deckCard2pb.Location = new System.Drawing.Point(837, 48);
            this.deckCard2pb.Name = "deckCard2pb";
            this.deckCard2pb.Size = new System.Drawing.Size(130, 180);
            this.deckCard2pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.deckCard2pb.TabIndex = 22;
            this.deckCard2pb.TabStop = false;
            // 
            // dealerCard2pb
            // 
            this.dealerCard2pb.BackColor = System.Drawing.Color.Transparent;
            this.dealerCard2pb.Location = new System.Drawing.Point(146, 29);
            this.dealerCard2pb.Name = "dealerCard2pb";
            this.dealerCard2pb.Size = new System.Drawing.Size(130, 180);
            this.dealerCard2pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dealerCard2pb.TabIndex = 23;
            this.dealerCard2pb.TabStop = false;
            // 
            // dealerCard3pb
            // 
            this.dealerCard3pb.BackColor = System.Drawing.Color.Transparent;
            this.dealerCard3pb.Location = new System.Drawing.Point(282, 29);
            this.dealerCard3pb.Name = "dealerCard3pb";
            this.dealerCard3pb.Size = new System.Drawing.Size(130, 180);
            this.dealerCard3pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dealerCard3pb.TabIndex = 24;
            this.dealerCard3pb.TabStop = false;
            // 
            // dealerCard4pb
            // 
            this.dealerCard4pb.BackColor = System.Drawing.Color.Transparent;
            this.dealerCard4pb.Location = new System.Drawing.Point(418, 29);
            this.dealerCard4pb.Name = "dealerCard4pb";
            this.dealerCard4pb.Size = new System.Drawing.Size(130, 180);
            this.dealerCard4pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dealerCard4pb.TabIndex = 25;
            this.dealerCard4pb.TabStop = false;
            // 
            // dealerCard5pb
            // 
            this.dealerCard5pb.BackColor = System.Drawing.Color.Transparent;
            this.dealerCard5pb.Location = new System.Drawing.Point(554, 29);
            this.dealerCard5pb.Name = "dealerCard5pb";
            this.dealerCard5pb.Size = new System.Drawing.Size(130, 180);
            this.dealerCard5pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dealerCard5pb.TabIndex = 26;
            this.dealerCard5pb.TabStop = false;
            // 
            // dealerCard6pb
            // 
            this.dealerCard6pb.BackColor = System.Drawing.Color.Transparent;
            this.dealerCard6pb.Location = new System.Drawing.Point(690, 29);
            this.dealerCard6pb.Name = "dealerCard6pb";
            this.dealerCard6pb.Size = new System.Drawing.Size(130, 180);
            this.dealerCard6pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dealerCard6pb.TabIndex = 27;
            this.dealerCard6pb.TabStop = false;
            // 
            // playerCard1
            // 
            this.playerCard1.BackColor = System.Drawing.Color.Transparent;
            this.playerCard1.Location = new System.Drawing.Point(10, 418);
            this.playerCard1.Name = "playerCard1";
            this.playerCard1.Size = new System.Drawing.Size(130, 180);
            this.playerCard1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.playerCard1.TabIndex = 28;
            this.playerCard1.TabStop = false;
            this.playerCard1.Visible = false;
            // 
            // playerCard2
            // 
            this.playerCard2.BackColor = System.Drawing.Color.Transparent;
            this.playerCard2.Location = new System.Drawing.Point(146, 418);
            this.playerCard2.Name = "playerCard2";
            this.playerCard2.Size = new System.Drawing.Size(130, 180);
            this.playerCard2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.playerCard2.TabIndex = 29;
            this.playerCard2.TabStop = false;
            this.playerCard2.Visible = false;
            // 
            // playerCard3
            // 
            this.playerCard3.BackColor = System.Drawing.Color.Transparent;
            this.playerCard3.Location = new System.Drawing.Point(282, 418);
            this.playerCard3.Name = "playerCard3";
            this.playerCard3.Size = new System.Drawing.Size(130, 180);
            this.playerCard3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.playerCard3.TabIndex = 30;
            this.playerCard3.TabStop = false;
            this.playerCard3.Visible = false;
            // 
            // Winstb
            // 
            this.Winstb.Location = new System.Drawing.Point(12, 279);
            this.Winstb.Name = "Winstb";
            this.Winstb.Size = new System.Drawing.Size(100, 20);
            this.Winstb.TabIndex = 31;
            // 
            // Lossestb
            // 
            this.Lossestb.Location = new System.Drawing.Point(12, 381);
            this.Lossestb.Name = "Lossestb";
            this.Lossestb.Size = new System.Drawing.Size(100, 20);
            this.Lossestb.TabIndex = 32;
            // 
            // Tiestb
            // 
            this.Tiestb.Location = new System.Drawing.Point(12, 330);
            this.Tiestb.Name = "Tiestb";
            this.Tiestb.Size = new System.Drawing.Size(100, 20);
            this.Tiestb.TabIndex = 33;
            // 
            // Winslbl
            // 
            this.Winslbl.AutoSize = true;
            this.Winslbl.BackColor = System.Drawing.Color.Transparent;
            this.Winslbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Winslbl.Location = new System.Drawing.Point(9, 263);
            this.Winslbl.Name = "Winslbl";
            this.Winslbl.Size = new System.Drawing.Size(31, 13);
            this.Winslbl.TabIndex = 34;
            this.Winslbl.Text = "Wins";
            // 
            // Tieslbl
            // 
            this.Tieslbl.AutoSize = true;
            this.Tieslbl.BackColor = System.Drawing.Color.Transparent;
            this.Tieslbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Tieslbl.Location = new System.Drawing.Point(9, 314);
            this.Tieslbl.Name = "Tieslbl";
            this.Tieslbl.Size = new System.Drawing.Size(27, 13);
            this.Tieslbl.TabIndex = 35;
            this.Tieslbl.Text = "Ties";
            // 
            // Losseslbl
            // 
            this.Losseslbl.AutoSize = true;
            this.Losseslbl.BackColor = System.Drawing.Color.Transparent;
            this.Losseslbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Losseslbl.Location = new System.Drawing.Point(9, 365);
            this.Losseslbl.Name = "Losseslbl";
            this.Losseslbl.Size = new System.Drawing.Size(40, 13);
            this.Losseslbl.TabIndex = 36;
            this.Losseslbl.Text = "Losses";
            // 
            // NewGamebtn
            // 
            this.NewGamebtn.Location = new System.Drawing.Point(735, 234);
            this.NewGamebtn.Name = "NewGamebtn";
            this.NewGamebtn.Size = new System.Drawing.Size(75, 23);
            this.NewGamebtn.TabIndex = 37;
            this.NewGamebtn.Text = "New Game";
            this.NewGamebtn.UseVisualStyleBackColor = true;
            this.NewGamebtn.Click += new System.EventHandler(this.NewGamebtn_Click);
            // 
            // Dealbtn
            // 
            this.Dealbtn.Location = new System.Drawing.Point(12, 234);
            this.Dealbtn.Name = "Dealbtn";
            this.Dealbtn.Size = new System.Drawing.Size(75, 23);
            this.Dealbtn.TabIndex = 38;
            this.Dealbtn.Text = "Deal";
            this.Dealbtn.UseVisualStyleBackColor = true;
            this.Dealbtn.Click += new System.EventHandler(this.Dealbtn_Click);
            // 
            // Standbtn
            // 
            this.Standbtn.Location = new System.Drawing.Point(163, 389);
            this.Standbtn.Name = "Standbtn";
            this.Standbtn.Size = new System.Drawing.Size(75, 23);
            this.Standbtn.TabIndex = 39;
            this.Standbtn.Text = "Stand";
            this.Standbtn.UseVisualStyleBackColor = true;
            this.Standbtn.Click += new System.EventHandler(this.Standbtn_Click);
            // 
            // Hitbtn
            // 
            this.Hitbtn.Location = new System.Drawing.Point(244, 389);
            this.Hitbtn.Name = "Hitbtn";
            this.Hitbtn.Size = new System.Drawing.Size(75, 23);
            this.Hitbtn.TabIndex = 40;
            this.Hitbtn.Text = "Hit";
            this.Hitbtn.UseVisualStyleBackColor = true;
            this.Hitbtn.Click += new System.EventHandler(this.Hitbtn_Click);
            // 
            // GameOvertb
            // 
            this.GameOvertb.Location = new System.Drawing.Point(589, 236);
            this.GameOvertb.Name = "GameOvertb";
            this.GameOvertb.Size = new System.Drawing.Size(140, 20);
            this.GameOvertb.TabIndex = 41;
            // 
            // DoubleDownbtn
            // 
            this.DoubleDownbtn.Location = new System.Drawing.Point(325, 389);
            this.DoubleDownbtn.Name = "DoubleDownbtn";
            this.DoubleDownbtn.Size = new System.Drawing.Size(81, 23);
            this.DoubleDownbtn.TabIndex = 42;
            this.DoubleDownbtn.Text = "Double Down";
            this.DoubleDownbtn.UseVisualStyleBackColor = true;
            this.DoubleDownbtn.Click += new System.EventHandler(this.DoubleDownbtn_Click);
            // 
            // Recordpnl
            // 
            this.Recordpnl.Location = new System.Drawing.Point(866, 292);
            this.Recordpnl.Name = "Recordpnl";
            this.Recordpnl.Size = new System.Drawing.Size(168, 306);
            this.Recordpnl.TabIndex = 43;
            // 
            // Betpnl
            // 
            this.Betpnl.Location = new System.Drawing.Point(496, 269);
            this.Betpnl.Name = "Betpnl";
            this.Betpnl.Size = new System.Drawing.Size(168, 109);
            this.Betpnl.TabIndex = 44;
            // 
            // PlayerHandTotaltb
            // 
            this.PlayerHandTotaltb.Location = new System.Drawing.Point(194, 349);
            this.PlayerHandTotaltb.Name = "PlayerHandTotaltb";
            this.PlayerHandTotaltb.Size = new System.Drawing.Size(100, 20);
            this.PlayerHandTotaltb.TabIndex = 45;
            // 
            // playerHandTotallbl
            // 
            this.playerHandTotallbl.AutoSize = true;
            this.playerHandTotallbl.BackColor = System.Drawing.Color.Transparent;
            this.playerHandTotallbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.playerHandTotallbl.Location = new System.Drawing.Point(191, 330);
            this.playerHandTotallbl.Name = "playerHandTotallbl";
            this.playerHandTotallbl.Size = new System.Drawing.Size(85, 13);
            this.playerHandTotallbl.TabIndex = 46;
            this.playerHandTotallbl.Text = "Your Hand Total";
            // 
            // DealerHandTotallbl
            // 
            this.DealerHandTotallbl.AutoSize = true;
            this.DealerHandTotallbl.BackColor = System.Drawing.Color.Transparent;
            this.DealerHandTotallbl.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.DealerHandTotallbl.Location = new System.Drawing.Point(191, 234);
            this.DealerHandTotallbl.Name = "DealerHandTotallbl";
            this.DealerHandTotallbl.Size = new System.Drawing.Size(94, 13);
            this.DealerHandTotallbl.TabIndex = 48;
            this.DealerHandTotallbl.Text = "Dealer Hand Total";
            // 
            // DealerHandTotaltb
            // 
            this.DealerHandTotaltb.Location = new System.Drawing.Point(194, 253);
            this.DealerHandTotaltb.Name = "DealerHandTotaltb";
            this.DealerHandTotaltb.Size = new System.Drawing.Size(100, 20);
            this.DealerHandTotaltb.TabIndex = 47;
            // 
            // ExitGamebtn
            // 
            this.ExitGamebtn.Location = new System.Drawing.Point(816, 234);
            this.ExitGamebtn.Name = "ExitGamebtn";
            this.ExitGamebtn.Size = new System.Drawing.Size(75, 23);
            this.ExitGamebtn.TabIndex = 49;
            this.ExitGamebtn.Text = "Exit Game";
            this.ExitGamebtn.UseVisualStyleBackColor = true;
            this.ExitGamebtn.Click += new System.EventHandler(this.ExitGamebtn_Click);
            // 
            // playerCard6
            // 
            this.playerCard6.BackColor = System.Drawing.Color.Transparent;
            this.playerCard6.Location = new System.Drawing.Point(700, 418);
            this.playerCard6.Name = "playerCard6";
            this.playerCard6.Size = new System.Drawing.Size(130, 180);
            this.playerCard6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.playerCard6.TabIndex = 52;
            this.playerCard6.TabStop = false;
            this.playerCard6.Visible = false;
            // 
            // playerCard5
            // 
            this.playerCard5.BackColor = System.Drawing.Color.Transparent;
            this.playerCard5.Location = new System.Drawing.Point(564, 418);
            this.playerCard5.Name = "playerCard5";
            this.playerCard5.Size = new System.Drawing.Size(130, 180);
            this.playerCard5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.playerCard5.TabIndex = 51;
            this.playerCard5.TabStop = false;
            this.playerCard5.Visible = false;
            // 
            // playerCard4
            // 
            this.playerCard4.BackColor = System.Drawing.Color.Transparent;
            this.playerCard4.Location = new System.Drawing.Point(428, 418);
            this.playerCard4.Name = "playerCard4";
            this.playerCard4.Size = new System.Drawing.Size(130, 180);
            this.playerCard4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.playerCard4.TabIndex = 50;
            this.playerCard4.TabStop = false;
            this.playerCard4.Visible = false;
            // 
            // BlackjackForm
            // 
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.backGreen;
            this.ClientSize = new System.Drawing.Size(1049, 628);
            this.Controls.Add(this.playerCard6);
            this.Controls.Add(this.playerCard5);
            this.Controls.Add(this.playerCard4);
            this.Controls.Add(this.ExitGamebtn);
            this.Controls.Add(this.Recordpnl);
            this.Controls.Add(this.DealerHandTotallbl);
            this.Controls.Add(this.DealerHandTotaltb);
            this.Controls.Add(this.playerHandTotallbl);
            this.Controls.Add(this.PlayerHandTotaltb);
            this.Controls.Add(this.Betpnl);
            this.Controls.Add(this.DoubleDownbtn);
            this.Controls.Add(this.GameOvertb);
            this.Controls.Add(this.Hitbtn);
            this.Controls.Add(this.Standbtn);
            this.Controls.Add(this.Dealbtn);
            this.Controls.Add(this.NewGamebtn);
            this.Controls.Add(this.Losseslbl);
            this.Controls.Add(this.Tieslbl);
            this.Controls.Add(this.Winslbl);
            this.Controls.Add(this.Tiestb);
            this.Controls.Add(this.Lossestb);
            this.Controls.Add(this.Winstb);
            this.Controls.Add(this.playerCard3);
            this.Controls.Add(this.playerCard2);
            this.Controls.Add(this.playerCard1);
            this.Controls.Add(this.dealerCard6pb);
            this.Controls.Add(this.dealerCard5pb);
            this.Controls.Add(this.dealerCard4pb);
            this.Controls.Add(this.dealerCard3pb);
            this.Controls.Add(this.dealerCard2pb);
            this.Controls.Add(this.deckCard2pb);
            this.Controls.Add(this.deckCard1pb);
            this.Controls.Add(this.dealerCard1pb);
            this.Controls.Add(this.deckCard3pb);
            this.Controls.Add(this.playerBanklbl);
            this.Controls.Add(this.btn10);
            this.Controls.Add(this.btn50);
            this.Controls.Add(this.btn25);
            this.Controls.Add(this.playerBanktb);
            this.Controls.Add(this.playerBettb);
            this.Controls.Add(this.btn100);
            this.Controls.Add(this.playerBetlbl);
            this.Controls.Add(this.ClrBetBtn);
            this.Name = "BlackjackForm";
            ((System.ComponentModel.ISupportInitialize)(this.deckCard3pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard1pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deckCard1pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deckCard2pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard2pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard3pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard4pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard5pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dealerCard6pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerCard4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private Button ClrBetBtn;
        private Label playerBetlbl;
        private Button btn100;
        private TextBox playerBettb;
        private TextBox playerBanktb;
        private Button btn25;
        private Button btn50;
        private Button btn10;
        private Label playerBanklbl;
        private PictureBox deckCard3pb;
        private PictureBox dealerCard1pb;
        private PictureBox deckCard1pb;
        private PictureBox deckCard2pb;
        private PictureBox dealerCard2pb;
        private PictureBox dealerCard3pb;
        private PictureBox dealerCard4pb;
        private PictureBox dealerCard5pb;
        private PictureBox dealerCard6pb;
        private PictureBox playerCard1;
        private PictureBox playerCard2;
        private PictureBox playerCard3;
        private TextBox Winstb;
        private TextBox Lossestb;
        private TextBox Tiestb;
        private Label Winslbl;
        private Label Tieslbl;
        private Label Losseslbl;
        private Button NewGamebtn;
        private Button Dealbtn;
        private Button Standbtn;
        private Button Hitbtn;
        private TextBox GameOvertb;
        private Button DoubleDownbtn;
        private Panel Recordpnl;
        private Panel Betpnl;
        private TextBox PlayerHandTotaltb;
        private Label playerHandTotallbl;
        private Label DealerHandTotallbl;
        private TextBox DealerHandTotaltb;
        private Button ExitGamebtn;
        private PictureBox playerCard6;
        private PictureBox playerCard5;
        private PictureBox playerCard4;
    }
}

