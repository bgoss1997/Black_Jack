﻿using System.Collections.Generic;
using Blackjack.BaseClasses;
using System.Windows.Forms;
using System;

namespace Blackjack
{
    public class Player
    {
        private decimal balance;
        private BlackJackHand hand;
        private decimal bet;
        private int wins;
        private int losses;
        private int pushes;
        private Shoe currentDeck;
        private List<Card> cards = new List<Card>();

        public Shoe CurrentDeck { get { return currentDeck; } set { currentDeck = value; } }
        public BlackJackHand Hand { get { return hand; } }
        public decimal Bet { get { return bet; } set { bet = value; } }
        public decimal Balance { get { return balance; } set { balance = value; } }
        public int Wins { get { return wins; } set { wins = value; } }
        public int Losses { get { return losses; } set { losses = value; } }
        public int Push { get { return pushes; } set { pushes = value; } }

        public Player()
        {
            this.hand = new BlackJackHand();
            this.balance = 4000;
        }

        public Player(int newBalance)
        {
            this.hand = new BlackJackHand();
            this.balance = newBalance;
        }

        public void IncreaseBet(decimal amt)
        { 
            if ((balance - (bet + amt)) >= 0)
            {
                bet += amt;
            }
            else
            {
                throw new Exception("You do not have enough money to make this bet.");
            }
        }

        public void PlaceBet()
        {
            if ((balance - bet) >= 0)
            {
                balance = balance - bet;
            }
            else
            {
                throw new Exception("You do not have enough money to place this bet.");
            }
        }

        public BlackJackHand NewHand()
        {
            this.hand = new BlackJackHand();
            return this.hand;
        }

        public void ClearBet()
        {
            bet = 0;
        }

        public bool HasBlackJack()
        {
            if (hand.GetSumOfHand() == 21)
                return true;
            else return false;
        }

        public bool HasBust()
        {
            if (hand.GetSumOfHand() > 21)
                return true;
            else return false;
        }

        public void Hit()
        {
            Card c = currentDeck.Draw();
            hand.Cards.Add(c);
        }

        public void DoubleDown()
        {
            IncreaseBet(Bet);
            balance = balance - (bet / 2);
            Hit();
        }
    }
}
