﻿using Blackjack.BaseClasses;
using System;
using System.Text;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using WindowsFormsApp1.Properties;

namespace Blackjack
{
    public partial class BlackjackForm : Form
    {

        private Table game = new Table();
        private PictureBox[] playerCards;
        private PictureBox[] dealerCards;
        private bool gameStart;

        public BlackjackForm()
        {
            InitializeComponent();
            LoadCardImages();
            SetUpNewGame();
        }

        private void Dealbtn_Click(object sender, EventArgs e)
        {
            
        }
        private void Standbtn_Click(object sender, EventArgs e)
        {
            game.DealerPlay();
            UpdateUIPlayerCards();

            EndGame(GetGameResult());
        }

        private void Hitbtn_Click(object sender, EventArgs e)
        {
            gameStart = false;

            game.CurrentPlayer.Hit();
            UpdateUIPlayerCards();

            if (game.CurrentPlayer.HasBust())
            {
                EndGame(EndResult.PlayerBust);
            }
        }

        private void NewGamebtn_Click(object sender, EventArgs e)
        {
            ClearTable();
            SetUpNewGame();
        }

        private void ExitGamebtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DoubleDownbtn_Click(object sender, EventArgs e)
        {
            
        }

        private void btn100_Click(object sender, EventArgs e)
        {
            Bet(100);
        }

        private void btn50_Click(object sender, EventArgs e)
        {
            Bet(50);
        }

        private void btn25_Click(object sender, EventArgs e)
        {
            Bet(25);
        }

        private void btn10_Click(object sender, EventArgs e)
        {
            Bet(10);
        }

        private void ClrBetBtn_Click(object sender, EventArgs e)
        {
            game.CurrentPlayer.ClearBet();
            ShowBankValue();
        }

        private void Bet(decimal betValue)
        {
            
        }

        private void ShowBankValue()
        {
            // Update the "My Account" value
            playerBanktb.Text = "$" + game.CurrentPlayer.Balance.ToString();
            playerBettb.Text = "$" + game.CurrentPlayer.Bet.ToString();
        }

        private void ClearTable()
        {
            for (int i = 0; i < 6; i++)
            {
                dealerCards[i].Image = null;
                dealerCards[i].Visible = false;

                playerCards[i].Image = null;
                playerCards[i].Visible = false;
            }
        }

        private EndResult GetGameResult()
        {

        }

        private void EndGame(EndResult endState)
        {

        }

        private void LoadCardImages()
        {

        }

        private void SetUpGameInPlay()
        {

        }

        private void SetUpNewGame()
        {

        }

        private void UpdateUIPlayerCards()
        {

        }

        private void LoadCard(PictureBox pb, Card c)
        {

        }
    }
}