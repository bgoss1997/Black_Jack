﻿using System;

namespace Blackjack.BaseClasses
{
    public enum Suit
    {
        Diamonds, Spades, Clubs, Hearts
    }

    public enum FaceValue
    {
        Two = 2, Three = 3, Four = 4, Five = 5, Six = 6, Seven = 7, Eight = 8,
        Nine = 9, Ten = 10, Jack = 11, Queen = 12, King = 13, Ace = 14
    }

    public class Card
    {
        private readonly Suit suit;
        private readonly FaceValue faceVal;
        private bool isCardUp;

        public Suit Suit { get { return suit; } }
        public FaceValue FaceVal { get { return faceVal; } }
        public bool IsCardUp { get { return isCardUp; } set { isCardUp = value; } }

        
        public Card(Suit suit, FaceValue faceVal, bool isCardUp)
        {
            this.suit = suit;
            this.faceVal = faceVal;
            this.isCardUp = isCardUp;
        }

        public override string ToString()
        {
            return "The" + faceVal.ToString() + "of" + suit.ToString();
        }
    }
}