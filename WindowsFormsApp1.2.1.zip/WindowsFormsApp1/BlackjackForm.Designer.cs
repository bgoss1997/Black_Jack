﻿using System;
using System.Windows.Forms;

namespace Blackjack
{
    partial class BlackjackForm
    {
    }
}

