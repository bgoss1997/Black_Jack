﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Blackjack.BaseClasses;
using System.Windows.Forms;

namespace Blackjack
{
    public partial class BlackjackForm : Form
    {
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // BlackjackForm
            // 
            this.ClientSize = new System.Drawing.Size(953, 628);
            this.Name = "BlackjackForm";
            this.ResumeLayout(false);

        }
    }
}