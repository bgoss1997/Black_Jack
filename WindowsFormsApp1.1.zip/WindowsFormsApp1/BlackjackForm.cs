﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blackjack
{
    public partial class BlackjackForm : Form
    {
        private readonly int STARTING_HAND = 2;
        private readonly int MAX_CARDS_ON_TABLE = 11;
        private PictureBox[] _players_Cards;
        private PictureBox[] _dealers_Cards;
        Shoe deck;
        Hand player { get; set; }
        Hand dealer { get; set; }
        private bool playerStaying = false;
        int dealerSum;
        int playerSum;

        public BlackjackForm()
        {
            InitializeComponent();
        }

        private void Blackjack_Load(object sender, EventArgs e)
        {
            New_Game();
        }

        private void New_Game()
        {
            Clear_Table();
            Initialize_Card_Places_On_Table();
        }

        private void Clear_Table()
        {
            _players_Cards = _dealers_Cards = null;
            dealerSum = playerSum = 0;
            player = dealer = null;
        }

        private void Initialize_Card_Places_On_Table()
        {
            dealer = new Hand(2, deck);
            player = new Hand(2, deck);
            
        }
        
        private void btnHit_Click(object sender, EventArgs e)
        {
            
            if (playerSum < 21)
            {
                player.AddValue(deck.DrawCard(player), ref playerSum);
                lblPlayerTotal.Text = "Player Total:" + playerSum.ToString();
            }
            else
            {
                lblPlayerTotal.Text = String.Format("Player has Bust with a total of {0}. Better luck next time!", playerSum);
            }
        }

        private void btnStay_Click(object sender, EventArgs e)
        {
            playerStaying = true;
        }

        private void Dealer_Hit()
        {
            if (playerStaying && dealerSum <= 15)
            {
                deck.DrawCard(dealer);
            }
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
