﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using WindowsFormsApp1.Properties;

namespace Blackjack 
{
    public class Card 
    {
        private Image _image;
        private CardRank _rank;
        private CardSuit _suit;
        public bool hidden;

        public enum CardRank
        {
            Ace = 0,
            Two = 1,
            Three = 2,
            Four = 3,
            Five = 4,
            Six = 5,
            Seven = 6,
            Eight = 7,
            Nine = 8,
            Ten = 9,
            Jack = 10,
            Queen = 11,
            King = 12

        }

        public enum CardSuit
        {
            Spades = 0,
            Diamonds = 1, 
            Hearts = 2, 
            Clubs = 3
        }

        public Image Image
        {
            get { return this._image; }
        }

        public CardRank Rank
        {
            get
            {
                return this._rank;
            }
            set
            {
                this._rank = value;
            }
        }

        public CardSuit Suit
        {
            get
            {
                return this._suit;
            }
            set
            {
                this._suit = value;
                GetImage();
            }
        }

        
        public Card(CardRank rank, CardSuit suit)
        {
            _rank = rank;
            _suit = suit;
            GetImage();
        }

        private void GetImage()
        {
            if (this.Suit != 0 && this._rank != 0)//so it must be a valid card (see the Enums)
            {
                int x = 0;//starting point from the left
                int y = 0;//starting point from the top. Can be 0, 98, 196 and 294
                int height = 97;
                int width = 73;

                switch (this.Suit)
                {
                    case CardSuit.Hearts:
                        y = 196;
                        break;
                    case CardSuit.Spades:
                        y = 98;
                        break;
                    case CardSuit.Clubs:
                        y = 0;
                        break;
                    case CardSuit.Diamonds:
                        y = 294;
                        break;
                }

                x = width * ((int)this._rank - 1);//the Ace has the value of 1 (see the Enum), so the X coordinate will be the starting (first one), that's why we have to subtract 1. The card 6 has the total width of the first 6 cards (6*73=438) minus the total width of the first 5 cards (5*73=365). Of course it is 73. The starting X coordinate is at the end of the 5th card (or the start of the left side of the 6th card). Hope you understand. :)

                Bitmap source = Resources.cards;//the original cards.png image
                Bitmap img = new Bitmap(width, height);//this will be the created one for each card
                Graphics g = Graphics.FromImage(img);
                g.DrawImage(source, new Rectangle(0, 0, width, height), new Rectangle(x, y, width, height), GraphicsUnit.Pixel);//here we slice the original into pieces
                g.Dispose();
                this._image = img;
            }
        }

        public override string ToString()
        {
            string realValue = "";
            switch (_rank)
            {
                case CardRank.Two:
                case CardRank.Three:
                case CardRank.Four:
                case CardRank.Five:
                case CardRank.Six:
                case CardRank.Seven:
                case CardRank.Eight:
                case CardRank.Nine:
                case CardRank.Ten:
                    realValue = ((int)_rank).ToString();
                    break;
                case CardRank.Jack:
                case CardRank.Queen:
                case CardRank.King:
                case CardRank.Ace:
                    realValue = _rank.ToString();
                    break;
            }
            return realValue + " of " + _suit.ToString();
        }
    }
}

