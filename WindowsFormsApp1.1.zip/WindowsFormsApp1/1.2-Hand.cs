﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Globalization;

namespace Blackjack
{
    public class Hand
    {
        private List<Card> _cards;
        private double _handTotal;
        private HandType _handStatus;
        const int _max_Hand_Size = 11; 
        const double startingHand = 2;
        private bool _hidden = false;

        public List<Card> Cards
        {
            get { return _cards; }
            set { }
        }

        public double HandSum
        {
            get { return _handTotal; }
            private set
            {
                foreach (Card card in _cards)
                {
                    if (card != null)
                    {
                        _handTotal += (double) card.Rank; 
                    }
                }
            }
        }

        public enum HandType //not yet implemented
        {
            None = 0,
            Win = 1,
            Lose = -2,
            Push = -1,
            Blackjack = 2
        }

        public Hand(int size, Shoe shoe)
        {
            if (shoe == null)
            {
                throw new Shoe.DeckException("No decks available to draw from!");
            }
            else if (shoe.Cards.Count == 0)
            {
                throw new Shoe.DeckException("No more cards to draw!");
            }
            else
            {
                _cards = new List<Card>(size);
                for (int i = 0; i < size; i++)
                {
                    shoe.DrawCard(this);
                }
            }
        }

        public void AddValue (Card drawn, ref int currentSum)
        {
            if (drawn.Rank == Card.CardRank.Ace)
            {
                if (currentSum <= 10)
                {
                    currentSum += 11;
                }
                else
                {
                    currentSum += 1;
                }
            }
            else if (drawn.Rank == Card.CardRank.Jack || drawn.Rank == Card.CardRank.Queen || drawn.Rank == Card.CardRank.King)
            {
                currentSum += 10;
            }
            else
            {
                currentSum += (int)drawn.Rank;
            }
        }
    }
}
