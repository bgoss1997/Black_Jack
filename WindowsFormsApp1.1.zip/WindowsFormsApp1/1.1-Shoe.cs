﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Globalization;
using System.Runtime.Serialization;

namespace Blackjack //v1
{
    public class Shoe
    {
        private List<Card> _cards;
        
        public List<Card> Cards
        {
            get { return this._cards; }
            set { this._cards = value; }
        }

        public Shoe()
        {
            Cards = new List<Card>();
            ShuffleNewDecks();
        }

        public void ShuffleNewDecks()
        {
            _cards.Clear();
            for (int i =  0; i < 4; i++) //Card Suits
            {
                for (int j = 0; j < 13; j++) //Card Ranks
                {
                    new Card( (Card.CardRank)j , (Card.CardSuit)i );
                }
            }
            Random r = new Random();
            _cards = _cards.OrderBy(x => r.Next()).ToList();
        }
        public Card DrawCard(Hand hand)
        {
            Card drawn = _cards[_cards.Count - 1];
            _cards.Remove(drawn);
            hand.Cards.Add(drawn);
            return drawn;
        }

        [Serializable]
        internal class DeckException : Exception
        {
            public DeckException()
            {
            }

            public DeckException(string message) : base(message)
            {
            }

            public DeckException(string message, Exception innerException) : base(message, innerException)
            {
            }

            protected DeckException(SerializationInfo info, StreamingContext context) : base(info, context)
            {
            }
        }
    }
}
