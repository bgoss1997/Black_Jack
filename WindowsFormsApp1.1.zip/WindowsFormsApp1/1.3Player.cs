﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack
{
    public class Player //not implemented
    {
        private double _bank;
        private double _betTotal;
        public double increment;

        public double Bank { get { return _bank; } }
        public double Bet
        {
            get { return _betTotal; }
            set
            {

            }
        }

        private void Increase_Bet()
        {

        }

        private void Decrease_Bet()
        {

        }
    }
}
