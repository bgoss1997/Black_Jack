﻿using System.Windows.Forms;

namespace Blackjack
{
    partial class BlackjackForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHit = new System.Windows.Forms.Button();
            this.lblDealerTotal = new System.Windows.Forms.Label();
            this.btnStay = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.lblPlayerTotal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnHit
            // 
            this.btnHit.Location = new System.Drawing.Point(866, 142);
            this.btnHit.Name = "btnHit";
            this.btnHit.Size = new System.Drawing.Size(75, 23);
            this.btnHit.TabIndex = 0;
            this.btnHit.Text = "Hit";
            this.btnHit.UseVisualStyleBackColor = true;
            this.btnHit.Click += new System.EventHandler(this.btnHit_Click);
            // 
            // lblDealerTotal
            // 
            this.lblDealerTotal.AutoSize = true;
            this.lblDealerTotal.Location = new System.Drawing.Point(842, 9);
            this.lblDealerTotal.Name = "lblDealerTotal";
            this.lblDealerTotal.Size = new System.Drawing.Size(65, 13);
            this.lblDealerTotal.TabIndex = 1;
            this.lblDealerTotal.Text = "Dealer Total";
            // 
            // btnStay
            // 
            this.btnStay.Location = new System.Drawing.Point(866, 171);
            this.btnStay.Name = "btnStay";
            this.btnStay.Size = new System.Drawing.Size(75, 23);
            this.btnStay.TabIndex = 2;
            this.btnStay.Text = "Stay";
            this.btnStay.UseVisualStyleBackColor = true;
            this.btnStay.Click += new System.EventHandler(this.btnStay_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.splitContainer1.Size = new System.Drawing.Size(836, 361);
            this.splitContainer1.SplitterDistance = 180;
            this.splitContainer1.TabIndex = 3;
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(984, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // lblPlayerTotal
            // 
            this.lblPlayerTotal.AutoSize = true;
            this.lblPlayerTotal.Location = new System.Drawing.Point(842, 208);
            this.lblPlayerTotal.Name = "lblPlayerTotal";
            this.lblPlayerTotal.Size = new System.Drawing.Size(63, 13);
            this.lblPlayerTotal.TabIndex = 5;
            this.lblPlayerTotal.Text = "Player Total";
            // 
            // BlackjackForm
            // 
            this.ClientSize = new System.Drawing.Size(984, 362);
            this.Controls.Add(this.lblPlayerTotal);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.btnStay);
            this.Controls.Add(this.lblDealerTotal);
            this.Controls.Add(this.btnHit);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "BlackjackForm";
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Button btnHit;
        private System.Windows.Forms.Label lblDealerTotal;
        private System.Windows.Forms.Button btnStay;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private MenuStrip menuStrip1;
        private Label lblPlayerTotal;
        /*
/// <summary>
/// Required designer variable.
/// </summary>
private System.ComponentModel.IContainer components = null;

/// <summary>
/// Clean up any resources being used.
/// </summary>
/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
protected override void Dispose(bool disposing)
{
if (disposing && (components != null))
{
components.Dispose();
}
base.Dispose(disposing);
}

#region Windows Form Designer generated code

/// <summary>
/// Required method for Designer support - do not modify
/// the contents of this method with the code editor.
/// </summary>
private void InitializeComponent()
{
this.btnDouble = new System.Windows.Forms.Button();
this.playerBtb = new System.Windows.Forms.TextBox();
this.playerFtb = new System.Windows.Forms.TextBox();
this.playerFLbl = new System.Windows.Forms.Label();
this.btnHit = new System.Windows.Forms.Button();
this.btnStand = new System.Windows.Forms.Button();
this.btnSplit = new System.Windows.Forms.Button();
this.btnNewGame = new System.Windows.Forms.Button();
this.playerBLbl = new System.Windows.Forms.Label();
this.button1 = new System.Windows.Forms.Button();
this.PlayerCardsLbl = new System.Windows.Forms.Label();
this.DealerCardsLbl = new System.Windows.Forms.Label();
this.ClearBtn = new System.Windows.Forms.Button();
this.SuspendLayout();
// 
// btnDouble
// 
this.btnDouble.Location = new System.Drawing.Point(161, 364);
this.btnDouble.Name = "btnDouble";
this.btnDouble.Size = new System.Drawing.Size(75, 23);
this.btnDouble.TabIndex = 1;
this.btnDouble.Text = "Double";
this.btnDouble.UseVisualStyleBackColor = true;
this.btnDouble.Click += new System.EventHandler(this.DblBtn_Click);
// 
// playerBtb
// 
this.playerBtb.Location = new System.Drawing.Point(14, 432);
this.playerBtb.Name = "playerBtb";
this.playerBtb.Size = new System.Drawing.Size(116, 20);
this.playerBtb.TabIndex = 3;
this.playerBtb.TextChanged += new System.EventHandler(this.playerBtb_TextChanged);
// 
// playerFtb
// 
this.playerFtb.Location = new System.Drawing.Point(12, 380);
this.playerFtb.Name = "playerFtb";
this.playerFtb.Size = new System.Drawing.Size(116, 20);
this.playerFtb.TabIndex = 4;
// 
// playerFLbl
// 
this.playerFLbl.AutoSize = true;
this.playerFLbl.Location = new System.Drawing.Point(12, 364);
this.playerFLbl.Name = "playerFLbl";
this.playerFLbl.Size = new System.Drawing.Size(68, 13);
this.playerFLbl.TabIndex = 5;
this.playerFLbl.Text = "Player Funds";
// 
// btnHit
// 
this.btnHit.Location = new System.Drawing.Point(242, 364);
this.btnHit.Name = "btnHit";
this.btnHit.Size = new System.Drawing.Size(75, 23);
this.btnHit.TabIndex = 6;
this.btnHit.Text = "Hit";
this.btnHit.UseVisualStyleBackColor = true;
this.btnHit.Click += new System.EventHandler(this.HitBtn_Click);
// 
// btnStand
// 
this.btnStand.Location = new System.Drawing.Point(323, 364);
this.btnStand.Name = "btnStand";
this.btnStand.Size = new System.Drawing.Size(75, 23);
this.btnStand.TabIndex = 7;
this.btnStand.Text = "Stand";
this.btnStand.UseVisualStyleBackColor = true;
this.btnStand.Click += new System.EventHandler(this.StandBtn_Click);
// 
// btnSplit
// 
this.btnSplit.Location = new System.Drawing.Point(404, 364);
this.btnSplit.Name = "btnSplit";
this.btnSplit.Size = new System.Drawing.Size(75, 23);
this.btnSplit.TabIndex = 8;
this.btnSplit.Text = "Split";
this.btnSplit.UseVisualStyleBackColor = true;
this.btnSplit.Click += new System.EventHandler(this.SplitBtn_Click);
// 
// btnNewGame
// 
this.btnNewGame.Location = new System.Drawing.Point(5, 4);
this.btnNewGame.Name = "btnNewGame";
this.btnNewGame.Size = new System.Drawing.Size(75, 23);
this.btnNewGame.TabIndex = 9;
this.btnNewGame.Text = "New Game";
this.btnNewGame.UseVisualStyleBackColor = true;
this.btnNewGame.Click += new System.EventHandler(this.DealBtn_Click);
// 
// playerBLbl
// 
this.playerBLbl.AutoSize = true;
this.playerBLbl.Location = new System.Drawing.Point(11, 416);
this.playerBLbl.Name = "playerBLbl";
this.playerBLbl.Size = new System.Drawing.Size(50, 13);
this.playerBLbl.TabIndex = 10;
this.playerBLbl.Text = "Bet Total";
// 
// button1
// 
this.button1.Location = new System.Drawing.Point(15, 458);
this.button1.Name = "button1";
this.button1.Size = new System.Drawing.Size(75, 23);
this.button1.TabIndex = 11;
this.button1.Text = "Place Bet";
this.button1.UseVisualStyleBackColor = true;
// 
// PlayerCardsLbl
// 
this.PlayerCardsLbl.AutoSize = true;
this.PlayerCardsLbl.Location = new System.Drawing.Point(2, 124);
this.PlayerCardsLbl.Name = "PlayerCardsLbl";
this.PlayerCardsLbl.Size = new System.Drawing.Size(36, 13);
this.PlayerCardsLbl.TabIndex = 12;
this.PlayerCardsLbl.Text = "Player";
// 
// DealerCardsLbl
// 
this.DealerCardsLbl.AutoSize = true;
this.DealerCardsLbl.Location = new System.Drawing.Point(1069, 9);
this.DealerCardsLbl.Name = "DealerCardsLbl";
this.DealerCardsLbl.Size = new System.Drawing.Size(38, 13);
this.DealerCardsLbl.TabIndex = 13;
this.DealerCardsLbl.Text = "Dealer";
// 
// ClearBtn
// 
this.ClearBtn.Location = new System.Drawing.Point(136, 429);
this.ClearBtn.Name = "ClearBtn";
this.ClearBtn.Size = new System.Drawing.Size(75, 23);
this.ClearBtn.TabIndex = 14;
this.ClearBtn.Text = "Clear";
this.ClearBtn.UseVisualStyleBackColor = true;
this.ClearBtn.Click += new System.EventHandler(this.ClearBtn_Click);
// 
// BlackjackForm
// 
this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
this.ClientSize = new System.Drawing.Size(1127, 541);
this.Controls.Add(this.ClearBtn);
this.Controls.Add(this.DealerCardsLbl);
this.Controls.Add(this.PlayerCardsLbl);
this.Controls.Add(this.button1);
this.Controls.Add(this.playerBLbl);
this.Controls.Add(this.btnNewGame);
this.Controls.Add(this.btnSplit);
this.Controls.Add(this.btnStand);
this.Controls.Add(this.btnHit);
this.Controls.Add(this.playerFLbl);
this.Controls.Add(this.playerFtb);
this.Controls.Add(this.playerBtb);
this.Controls.Add(this.btnDouble);
this.Name = "BlackjackForm";
this.Text = "BlackJack";
this.Load += new System.EventHandler(this.Blackjack_Load);
this.ResumeLayout(false);
this.PerformLayout();

}

#endregion

private System.Windows.Forms.Button btnDouble;
private System.Windows.Forms.TextBox playerBtb;
private System.Windows.Forms.TextBox playerFtb;
private System.Windows.Forms.Label playerFLbl;
private System.Windows.Forms.Button btnHit;
private System.Windows.Forms.Button btnStand;
private System.Windows.Forms.Button btnSplit;
private System.Windows.Forms.Button btnNewGame;
private System.Windows.Forms.Label playerBLbl;
private System.Windows.Forms.Button button1;
private System.Windows.Forms.Label PlayerCardsLbl;
private System.Windows.Forms.Label DealerCardsLbl;
private System.Windows.Forms.Button ClearBtn;
*/
    }
}

