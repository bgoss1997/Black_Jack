﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blackjack
{
    public partial class BlackjackForm : Form
    {
        private readonly int STARTING_HAND = 2;
        private readonly int MAX_CARDS_ON_TABLE = 11;//worst case: you could have maximum 11 cards in hand (four 2s + four 3s + four 1s = 21)
        PictureBox p;
        PictureBox q;
        Shoe deck;
        Hand player;
        Hand dealer;
        int dealerSum;
        int playerSum;

        public BlackjackForm() => InitializeComponent();

        private void Blackjack_Load(object sender, EventArgs e)
        {

        }

        private void ClearTable()
        {

        }

        private void InitializeCardPlacesOnTable()
        {

        }
        
        private void btnHit_Click(object sender, EventArgs e)
        {

        }

        private void btnStay_Click(object sender, EventArgs e)
        {

        }

        private void dealerHit()
        {

        }


        /*private void playerBtb_TextChanged(object sender, EventArgs e)
        {

        }

        private void DblBtn_Click(object sender, EventArgs e)
        {

        }

        private void HitBtn_Click(object sender, EventArgs e)
        {

        }

        private void StandBtn_Click(object sender, EventArgs e)
        {

        }

        private void SplitBtn_Click(object sender, EventArgs e)
        {

        }

        private void DealBtn_Click(object sender, EventArgs e)
        {

        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {

        }
        */
    }
}
