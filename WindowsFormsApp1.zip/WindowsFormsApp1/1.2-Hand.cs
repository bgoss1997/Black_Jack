﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Globalization;

namespace Blackjack //v1
{
    public class Hand
    {
        private List<Card> _cards;
        
        public List<Card> Cards
        {
            get { return _cards; }
        }

        public Hand(int startingHand, Shoe shoe)
        {
            if (shoe == null)
            {
                throw new Shoe.DeckException("No decks available to draw from!");
            }
            else if (shoe.Cards.Count == 0)
            {
                throw new Shoe.DeckException("No more cards to draw!");
            }
            else
            {
                _cards = new List<Card>();
                for (int i = 0; i < startingHand; i++)
                {
                    shoe.DrawCard(this);
                }
            }
        }

        public void AddValue (Card drawn, ref int currentSum)
        {
            if (drawn.Rank == Card.CardRank.Ace)
            {
                if (currentSum <= 10)
                {
                    currentSum += 11;
                }
                else
                {
                    currentSum += 1;
                }
            }
            else if (drawn.Rank == Card.CardRank.Jack || drawn.Rank == Card.CardRank.Queen || drawn.Rank == Card.CardRank.King)
            {
                currentSum += 10;
            }
            else
            {
                currentSum += (int)drawn.Rank;
            }
        }
    }
}
