﻿using System;

namespace Blackjack.BaseClasses
{
    public enum Suit
    {
        Diamonds, Spades, Clubs, Hearts
    }

    public enum FaceValue
    {
        Two = 2, Three = 3, Four = 4, Five = 5, Six = 6, Seven = 7, Eight = 8,
        Nine = 9, Ten = 10, Jack = 11, Queen = 12, King = 13, Ace = 14
    }

    public class Card
    {
        private readonly Suit _suit;
        private readonly FaceValue _faceVal;
        private bool _isCardUp;

        public Suit Suit { get { return _suit; } }
        public FaceValue FaceVal { get { return _faceVal; } }
        public bool IsCardUp { get { return _isCardUp; } set { _isCardUp = value; } }

        
        public Card(Suit suit, FaceValue faceVal, bool isCardUp)
        {
            this._suit = suit;
            this._faceVal = faceVal;
            this._isCardUp = isCardUp;
        }

        public override string ToString()
        {
            return "The" + _faceVal.ToString() + "of" + _suit.ToString();
        }
    }
}