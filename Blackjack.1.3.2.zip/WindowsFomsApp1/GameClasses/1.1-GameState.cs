﻿namespace WindowsFormsApp1
{
    public enum EndResult
    {
        DealerBlackJack, PlayerBlackJack, PlayerBust, DealerBust, Push, PlayerWin, DealerWin
    }
}