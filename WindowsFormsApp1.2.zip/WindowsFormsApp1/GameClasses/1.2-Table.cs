﻿using System.Collections.Generic;
using Blackjack.BaseClasses;

namespace Blackjack
{
    public class Table
    {
        
        private Shoe deck;
        private Player dealer;
        private Player player;

        public Player CurrentPlayer { get { return player; } }
        public Player Dealer { get { return dealer; } }
        public Shoe CurrentDeck { get { return deck; } }

        public Table()
        {
            dealer = new Player();
            player = new Player();
        }

        public void DealNewGame()
        {
            deck = new Shoe();
            deck.Shuffle();
            player.NewHand();
            dealer.NewHand();

            for (int i = 0; i < 2; i++)
            {
                Card c = deck.Draw();
                player.Hand.Cards.Add(c);

                Card d = deck.Draw();
                if (i == 1)
                    d.IsCardUp = false;

                dealer.Hand.Cards.Add(d);
            }
            player.CurrentDeck = deck;
            dealer.CurrentDeck = deck;
        }

        public void DealerPlay()
        {
            dealer.Hand.Cards[1].IsCardUp = true;
            if (dealer.Hand.GetSumOfHand() < 17)
            {
                dealer.Hit();
                DealerPlay();
            }
        }
    }
}
