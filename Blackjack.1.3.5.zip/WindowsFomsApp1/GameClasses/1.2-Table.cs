﻿using WindowsFormsApp1.BaseClasses;

namespace WindowsFormsApp1
{
    public class Table
    {
        
        private Shoe _deck;
        private Player _dealer;
        private Player _player;

        public Player CurrentPlayer { get { return _player; } }
        public Player Dealer { get { return _dealer; } }
        public Shoe CurrentDeck { get { return _deck; } }

        public Table()
        {
            _dealer = new Player(0);
            _player = new Player(4000);
        }

        public void DealNewGame()
        {
            _deck = new Shoe();
            _deck.Shuffle();
            _player.NewHand();
            _dealer.NewHand();

            for (int i = 0; i < 2; i++)
            {
                Card c = _deck.Draw();
                _player.Hand.Cards.Add(c);

                Card d = _deck.Draw();
                if (i == 1)
                    d.IsCardUp = false;

                _dealer.Hand.Cards.Add(d);
            }
            _player.CurrentDeck = _deck;
            _dealer.CurrentDeck = _deck;
        }

        public void DealerPlay()
        {
            _dealer.Hand.Cards[1].IsCardUp = true;
            if (_dealer.Hand.GetSumOfHand() < 17)
            {
                _dealer.Hit();
                DealerPlay();
            }
        }

        public void PlayerLose()
        {
            _player.Losses += 1;
        }


        public void PlayerWin()
        {
            _player.Balance += _player.Bet * 2;
            _player.Wins += 1;
        }
    }
}
