﻿using WindowsFormsApp1.BaseClasses;
using System;
using System.Text;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

namespace WindowsFormsApp1
{
    //Not completely sure why, but the namespace must be WindowsFormsApp1, not Blackjack, for the current build to run properly. 
    //That might not be accurate, but hopefully I can change it and still have the build run.

    public partial class BlackjackForm : Form 
    {
        #region Fields
        private Table _game = new Table();
        private PictureBox[] playerCards;
        private PictureBox[] dealerCards;
        private bool gameStart;

        //allows access to card image files
        ResourceManager rm = new ResourceManager("WindowsFormsApp1.Properties.Resources", Assembly.GetExecutingAssembly());
        #endregion

        //Constructor
        public BlackjackForm()
        {
            InitializeComponent();
            LoadCardImages();
            SetUpNewGame();
        }

        #region Event Buttons
        /// <summary>
        /// After player places their bet, they may receive their cards
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Dealbtn_Click(object sender, EventArgs e)
        {
            try
            {
                if ((_game.CurrentPlayer.Bet == 0) && (_game.CurrentPlayer.Balance > 0))
                {
                    MessageBox.Show("You have to place a bet before the dealer deals.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    ShowBankValue();
                    _game.CurrentPlayer.PlaceBet();
                    ShowBankValue();

                    ClearTable();
                    SetUpGameInPlay();
                    _game.DealNewGame();
                    UpdateUIPlayerCards();

                    if (_game.CurrentPlayer.HasBlackJack())
                    {
                        EndGame(EndResult.PlayerBlackJack);
                    }
                }
            }
            catch (Exception NotEnoughMoneyException)
            {
                MessageBox.Show(NotEnoughMoneyException.Message);
            }
        }
        /// <summary>
        /// Once Player is satisfied with their hand, then they will allow the dealer to play
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Standbtn_Click(object sender, EventArgs e)
        {
            _game.DealerPlay();
            UpdateUIPlayerCards();
            //update dealer hand total before ending game
            DealerHandTotaltb.Text = _game.Dealer.Hand.GetSumOfHand().ToString();
            EndGame(GetGameResult());
        }
        /// <summary>
        /// Player adds a card from the deck to their hand
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Hitbtn_Click(object sender, EventArgs e)
        {
            gameStart = false;

            _game.CurrentPlayer.Hit();
            UpdateUIPlayerCards();

            if (_game.CurrentPlayer.HasBust())
            {
                EndGame(EndResult.PlayerBust);
            }
        }
        /// <summary>
        /// Resets the table and both the player and the dealer's hands, also clears the Wins, Losses, and Ties tally
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NewGamebtn_Click(object sender, EventArgs e)
        {
            ClearTable();
            SetUpNewGame();
        }
        /// <summary>
        /// Closes the application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExitGamebtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// Allows player to double down, but may not be 100% accurate to rules
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DoubleDownbtn_Click(object sender, EventArgs e)
        {
            try
            {
                _game.CurrentPlayer.DoubleDown();
                UpdateUIPlayerCards();
                ShowBankValue();

                if (_game.CurrentPlayer.HasBust())
                {
                    EndGame(EndResult.PlayerBust);
                }
                else
                {
                    _game.DealerPlay();
                    UpdateUIPlayerCards();
                    EndGame(GetGameResult());
                }
            }
            catch (Exception NotEnoughMoneyException)
            {
                MessageBox.Show(NotEnoughMoneyException.Message);
            }
        }
        /// <summary>
        /// Opens a web page that explains the basics and rules of blackjack
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Ruleslinklbl_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Ruleslinklbl.LinkVisited = true;
            System.Diagnostics.Process.Start("https://www.blackjackinfo.com/blackjack-rules/");
        }

        private void btn100_Click(object sender, EventArgs e)
        {
            Bet(100);
        }

        private void btn50_Click(object sender, EventArgs e)
        {
            Bet(50);
        }

        private void btn25_Click(object sender, EventArgs e)
        {
            Bet(25);
        }

        private void btn10_Click(object sender, EventArgs e)
        {
            Bet(10);
        }

        private void ClrBetBtn_Click(object sender, EventArgs e)
        {
            _game.CurrentPlayer.ClearBet();
            ShowBankValue();
        }

        #endregion

        #region Blackjack Methods
        /// <summary>
        /// Adjusts Player's bet
        /// </summary>
        /// <param name="betValue"></param>
        private void Bet(decimal betValue)
        {
            try
            {
                // Update the bet amount
                _game.CurrentPlayer.IncreaseBet(betValue);

                // Update the "Your Bet" and "Your Bank" values
                ShowBankValue();
            }
            catch (Exception NotEnoughMoneyException)
            {
                MessageBox.Show(NotEnoughMoneyException.Message);
            }
        }
        /// <summary>
        /// Displays player's remaining funds
        /// </summary>
        private void ShowBankValue()
        {
            // Update the "Your Bank" value
            playerBanktb.Text = "$" + _game.CurrentPlayer.Balance.ToString();
            playerBettb.Text = "$" + _game.CurrentPlayer.Bet.ToString();
        }
        /// <summary>
        /// Removes card images and makes the corresponding pictureboxes invisible
        /// </summary>
        private void ClearTable()
        {
            for (int i = 0; i < 6; i++)
            {
                dealerCards[i].Image = null;
                dealerCards[i].Visible = false;

                playerCards[i].Image = null;
                playerCards[i].Visible = false;
            }
        }
        /// <summary>
        /// An enumeration (found in GameState.cs) of the possible outcomes of a blackjack game
        /// </summary>
        /// <returns></returns>
        private EndResult GetGameResult()
        {
            EndResult endState;
            // Check for blackjack
            if (_game.Dealer.Hand.NumCards == 2 && _game.Dealer.HasBlackJack())
            {
                endState = EndResult.DealerBlackJack;
            }
            // Check if the dealer has bust
            else if (_game.Dealer.HasBust())
            {
                endState = EndResult.DealerBust;
            }
            else if (_game.Dealer.Hand.CompareFaceValue(_game.CurrentPlayer.Hand) > 0)
            {
                //dealer wins
                endState = EndResult.DealerWin;
            }
            else if (_game.Dealer.Hand.CompareFaceValue(_game.CurrentPlayer.Hand) == 0)
            {
                // push
                endState = EndResult.Push;
            }
            else
            {
                // player wins
                endState = EndResult.PlayerWin;
            }
            return endState;
        }
        /// <summary>
        /// Displays the result of the game in the GameOver Text Box to notify the player
        /// </summary>
        /// <param name="endState"></param>
        private void EndGame(EndResult endState)
        {
            switch (endState)
            {
                case EndResult.DealerBust:
                    GameOvertb.Text = "Dealer Bust!";
                    _game.PlayerWin();
                    break;
                case EndResult.DealerBlackJack:
                    GameOvertb.Text = "Dealer BlackJack!";
                    _game.PlayerLose();
                    break;
                case EndResult.DealerWin:
                    GameOvertb.Text = "Dealer Won!";
                    _game.PlayerLose();
                    break;
                case EndResult.PlayerBlackJack:
                    GameOvertb.Text = "BlackJack!";
                    _game.CurrentPlayer.Balance += (_game.CurrentPlayer.Bet * (decimal)2.5);
                    _game.CurrentPlayer.Wins += 1;
                    break;
                case EndResult.PlayerBust:
                    GameOvertb.Text = "You Bust!";
                    _game.PlayerLose();
                    break;
                case EndResult.PlayerWin:
                    GameOvertb.Text = "You Won!";
                    _game.PlayerWin();
                    break;
                case EndResult.Push:
                    GameOvertb.Text = "Push";
                    _game.CurrentPlayer.Push += 1;
                    _game.CurrentPlayer.Balance += _game.CurrentPlayer.Bet;
                    break;
            }

            Winstb.Text = _game.CurrentPlayer.Wins.ToString();
            Lossestb.Text = _game.CurrentPlayer.Losses.ToString();
            Tiestb.Text = _game.CurrentPlayer.Push.ToString();
            SetUpNewGame();
            ShowBankValue();
            GameOvertb.Show();
            // Check if the current player is out of money
            if (_game.CurrentPlayer.Balance == 0)
            {
                MessageBox.Show("Out of Money.  Please create a new game to play again.");
                this.Close();
            }
        }
        /// <summary>
        /// Prevents player from changing their bet after they have been dealt their cards
        /// </summary>
        private void SetUpGameInPlay()
        {
            btn10.Enabled = false;
            btn25.Enabled = false;
            btn50.Enabled = false;
            btn100.Enabled = false;
            ClrBetBtn.Enabled = false;
            Standbtn.Enabled = true;
            Hitbtn.Enabled = true;
            GameOvertb.Hide();
            playerHandTotallbl.Show();
            Dealbtn.Enabled = false;

            if (gameStart)
                DoubleDownbtn.Enabled = true;
        }
        /// <summary>
        /// Initializes the player's UI whenever they start a new hand or game
        /// </summary>
        private void SetUpNewGame()
        {
            Dealbtn.Enabled = true;
            DoubleDownbtn.Enabled = false;
            Standbtn.Enabled = false;
            Hitbtn.Enabled = false;
            ClrBetBtn.Enabled = true;
            btn10.Enabled = true;
            btn25.Enabled = true;
            btn50.Enabled = true;
            btn100.Enabled = true;
            GameOvertb.Hide();
            playerHandTotallbl.Hide();
            gameStart = true;
            ShowBankValue();
        }
        #endregion

        #region UI Methods
        /// <summary>
        /// Loads the cardBack.png file from resources
        /// </summary>
        private void LoadCardImages()
        {
            try
            {
                // Load the card skin image from Resources
                deckCard1pb.Image = (System.Drawing.Bitmap)rm.GetObject("cardSkin");
                deckCard2pb.Image = (System.Drawing.Bitmap)rm.GetObject("cardSkin");
                deckCard3pb.Image = (System.Drawing.Bitmap)rm.GetObject("cardSkin");
            }
            catch (OutOfMemoryException)
            {
                MessageBox.Show("Card skin images are not loading correctly.  Make sure the card skin images are in the correct location.");
            }

            playerCards = new PictureBox[] { playerCard1, playerCard2, playerCard3, playerCard4, playerCard5, playerCard6 };
            dealerCards = new PictureBox[] { dealerCard1pb, dealerCard2pb, dealerCard3pb, dealerCard4pb, dealerCard5pb, dealerCard6pb };
        }
        /// <summary>
        /// Updates the player's cards and card total
        /// </summary>
        private void UpdateUIPlayerCards()
        {
            // Update the value of the hand
            PlayerHandTotaltb.Text = _game.CurrentPlayer.Hand.GetSumOfHand().ToString();

            List<Card> pcards = _game.CurrentPlayer.Hand.Cards;
            for (int i = 0; i < pcards.Count; i++)
            {
                // Load each card from file
                LoadCard(playerCards[i], pcards[i]);
                playerCards[i].Visible = true;
                playerCards[i].BringToFront();
            }

            List<Card> dcards = _game.Dealer.Hand.Cards;
            for (int i = 0; i < dcards.Count; i++)
            {
                LoadCard(dealerCards[i], dcards[i]);
                dealerCards[i].Visible = true;
                dealerCards[i].BringToFront();
            }
        }
        /// <summary>
        /// Loads the corresponding card image to the correct picturebox
        /// </summary>
        /// <param name="pb"></param>
        /// <param name="c"></param>
        private void LoadCard(PictureBox pb, Card c)
        {
            try
            {
                //builds a string to search for appropriate file name

                StringBuilder image = new StringBuilder();
                switch (c.Suit)
                {
                    case Suit.Diamonds:
                        image.Append("di");
                        break;
                    case Suit.Hearts:
                        image.Append("he");
                        break;
                    case Suit.Spades:
                        image.Append("sp");
                        break;
                    case Suit.Clubs:
                        image.Append("cl");
                        break;
                }

                switch (c.FaceVal)
                {
                    case FaceValue.Ace:
                        image.Append("1");
                        break;
                    case FaceValue.King:
                        image.Append("k");
                        break;
                    case FaceValue.Queen:
                        image.Append("q");
                        break;
                    case FaceValue.Jack:
                        image.Append("j");
                        break;
                    case FaceValue.Ten:
                        image.Append("10");
                        break;
                    case FaceValue.Nine:
                        image.Append("9");
                        break;
                    case FaceValue.Eight:
                        image.Append("8");
                        break;
                    case FaceValue.Seven:
                        image.Append("7");
                        break;
                    case FaceValue.Six:
                        image.Append("6");
                        break;
                    case FaceValue.Five:
                        image.Append("5");
                        break;
                    case FaceValue.Four:
                        image.Append("4");
                        break;
                    case FaceValue.Three:
                        image.Append("3");
                        break;
                    case FaceValue.Two:
                        image.Append("2");
                        break;
                }
                
                //check if card is facing down, then replace with the right file name
                if (!c.IsCardUp)
                    image.Replace(image.ToString(), "cardSkin");

                pb.Image = (System.Drawing.Bitmap)rm.GetObject(image.ToString()); 
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Card images are not loading correctly.  Make sure all card images are in the right location.");
            }
        }
        #endregion
    }
}