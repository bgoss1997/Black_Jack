﻿using System.Collections.Generic;
using WindowsFormsApp1.BaseClasses;
using System;

namespace WindowsFormsApp1
{
    public class Player
    {
        private decimal _balance;
        private BlackJackHand _hand;
        private decimal _bet;
        private int _wins;
        private int _losses;
        private int _pushes;
        private Shoe _currentDeck;
        private List<Card> _cards = new List<Card>();

        public Shoe CurrentDeck { get { return _currentDeck; } set { _currentDeck = value; } }
        public BlackJackHand Hand { get { return _hand; } }
        public decimal Bet { get { return _bet; } set { _bet = value; } }
        public decimal Balance { get { return _balance; } set { _balance = value; } }
        public int Wins { get { return _wins; } set { _wins = value; } }
        public int Losses { get { return _losses; } set { _losses = value; } }
        public int Push { get { return _pushes; } set { _pushes = value; } }

        public Player(int newBalance)
        {
            this._hand = new BlackJackHand();
            this._balance = newBalance;
        }

        public void IncreaseBet(decimal amt)
        { 
            if ((_balance - (_bet + amt)) >= 0)
            {
                _bet += amt;
            }
            else
            {
                throw new Exception("You do not have enough money to make this bet.");
            }
        }

        public void PlaceBet()
        {
            if ((_balance - _bet) >= 0)
            {
                _balance = _balance - _bet;
            }
            else
            {
                throw new Exception("You do not have enough money to place this bet.");
            }
        }

        public BlackJackHand NewHand()
        {
            this._hand = new BlackJackHand();
            return this._hand;
        }

        public void ClearBet()
        {
            _bet = 0;
        }

        public bool HasBlackJack()
        {
            if (_hand.GetSumOfHand() == 21)
                return true;
            else return false;
        }

        public bool HasBust()
        {
            if (_hand.GetSumOfHand() > 21)
                return true;
            else return false;
        }

        public void Hit()
        {
            Card c = _currentDeck.Draw();
            _hand.Cards.Add(c);
        }

        public void DoubleDown()
        {
            IncreaseBet(Bet);
            _balance = _balance - (_bet / 2);
            Hit();
        }
    }
}
